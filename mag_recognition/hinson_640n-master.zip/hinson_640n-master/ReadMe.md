1. 采用CanOpen协议，磁导航传感器的nodeid（非canid）应配置为1和2
2. 假定系统用户名为“nav”，需要创建日志目录，即`/home/nav/log`
3. 通过话题`/hinson_640n/enable_hight_frequency_log`控制日志频繁打印的日志输出，用于拍错，默认禁用
4. 通过话题`/hinson_640n/magnetic_data`获取传感器相对磁条的距离，单位mm
