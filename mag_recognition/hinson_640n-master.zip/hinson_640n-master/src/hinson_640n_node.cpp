#include "magnetic_sensor.h"

int main(int argc, char **argv)
{
  google::InitGoogleLogging(argv[0]);
  FLAGS_stop_logging_if_full_disk = true;
  FLAGS_max_log_size = 3;
  FLAGS_logbufsecs = 0;
  FLAGS_colorlogtostderr = true;
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  ros::init(argc, argv, "hinson_640n_node");
  ros::NodeHandle private_nh("~");

  MagneticSensor ms(&private_nh);
  if (!ms.start())
    return 0;

  ros::Rate rate(300);
  while (ros::ok())
  {
    ms.eventLoop();
    ros::spinOnce();
    rate.sleep();
  }

  LOG(INFO) << "------>>>>>> exit!";

  return 0;
}