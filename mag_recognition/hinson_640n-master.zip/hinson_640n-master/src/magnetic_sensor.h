#ifndef __MAGNETIC_SENSOR_H__
#define __MAGNETIC_SENSOR_H__

#include "esd_can_drive.h"
#include <vector>
#include <ros/ros.h>
#include <std_msgs/Bool.h>
#include <gflags/gflags.h>
#include <glog/logging.h>
#include <glog/stl_logging.h>

typedef struct
{
  bool synch_mode_set;
  bool timer_set;
  bool send_set;
  ros::Time receive_point;
} SENSOR_DATA;

class MagneticSensor
{
public:
  enum NODE_ID
  {
    ID_0 = 0, // 广播
    ID_1 = 1, // 传感器1
    ID_2 = 2, // 传感器2
    ID_MAX
  };

public:
  MagneticSensor(ros::NodeHandle *private_nh);
  ~MagneticSensor();
  bool start();
  void eventLoop();

private:
  void configTPDO2Sync(uint8_t node_id); // 包含磁条位置的TPDO
  void configTPDO2Timer(uint8_t node_id);
  void emitTPDO2(uint8_t node_id);
  void configSensors();
  void timeoutCheck();
  void receiveData();

  void logEnableCallback(const std_msgs::Bool::ConstPtr &input);

private:
  EsdCanClient* esd_;
  SENSOR_DATA sensors_[NODE_ID::ID_MAX];
  bool high_frequency_log_;
  ros::Publisher sensor_data_pub_;
  ros::Subscriber log_sub_;
};

#endif