#include "magnetic_sensor.h"
#include "hinson_640n/Hinson640nData.h"
#include <unistd.h>

#define COM_MS 10 // 10 ms

MagneticSensor::MagneticSensor(ros::NodeHandle *private_nh)
{
  high_frequency_log_ = false;
  for (int i = NODE_ID::ID_1; i < NODE_ID::ID_MAX; ++i)
  {
    sensors_[i].synch_mode_set = false;
    sensors_[i].timer_set = false;
    sensors_[i].send_set = false;
  }

  log_sub_ = private_nh->subscribe("enable_hight_frequency_log", 1, &MagneticSensor::logEnableCallback, this);
  sensor_data_pub_ = private_nh->advertise<hinson_640n::Hinson640nData>("magnetic_data", 1);
  esd_ = new EsdCanClient(private_nh->param<int>("can_port", 0), NTCAN_BAUD_1000);
}

MagneticSensor::~MagneticSensor()
{
  esd_->Stop();
  delete esd_;
}

bool MagneticSensor::start()
{
  if (esd_->Start() != 1)
  {
    LOG(ERROR) << "Faild to start CAN-BUS!";
    return false;
  }
  return true;
}

void MagneticSensor::configTPDO2Sync(uint8_t node_id)
{
  if (sensors_[node_id].synch_mode_set)
    return;
  std::vector<CanFrame> msgs;
  msgs.clear();
  CanFrame msg;
  msg.id = 0x600 + node_id;
  msg.len = 8;
  msg.data[0] = 0x2F;
  msg.data[1] = 0x01;
  msg.data[2] = 0x18;
  msg.data[3] = 0x02;
  msg.data[4] = 0xFE;
  msg.data[5] = 0x00;
  msg.data[6] = 0x00;
  msg.data[7] = 0x00;
  msgs.push_back(msg);
  int len = msgs.size();
  esd_->Send(msgs, &len);
  usleep(100);
}

void MagneticSensor::configTPDO2Timer(uint8_t node_id)
{
  if (sensors_[node_id].timer_set)
    return;
  std::vector<CanFrame> msgs;
  msgs.clear();
  CanFrame msg;
  msg.id = 0x600 + node_id;
  msg.len = 8;
  msg.data[0] = 0x2F;
  msg.data[1] = 0x01;
  msg.data[2] = 0x18;
  msg.data[3] = 0x05;
  msg.data[4] = COM_MS;
  msg.data[5] = 0x00;
  msg.data[6] = 0x00;
  msg.data[7] = 0x00;
  msgs.push_back(msg);
  int len = msgs.size();
  esd_->Send(msgs, &len);
  usleep(100);
}

void MagneticSensor::emitTPDO2(uint8_t node_id)
{
  if (sensors_[node_id].synch_mode_set && sensors_[node_id].timer_set && !sensors_[node_id].send_set)
  {
    std::vector<CanFrame> msgs;
    msgs.clear();
    CanFrame msg;
    msg.id = 0;
    msg.len = 2;
    msg.data[0] = 0x01;
    msg.data[1] = node_id;
    msgs.push_back(msg);
    int len = msgs.size();
    esd_->Send(msgs, &len);
    sensors_[node_id].send_set = true;
  }
}

void MagneticSensor::receiveData()
{
  std::vector<CanFrame> frames;
  int frames_size = 6;
  int node_id;
  SENSOR_DATA *sensor = nullptr;

  if (esd_->Receive(&frames, &frames_size) == 1)
  {
    for (int i = 0; i < frames_size; ++i)
    {
      // std::cout << "id: " << frames[i].id << ", [" << std::hex << (int)frames[i].data[0] << ", " << (int)frames[i].data[1] << ", " << (int)frames[i].data[2] << ", " << (int)frames[i].data[3] << ", " << (int)frames[i].data[4] << ", " << (int)frames[i].data[5] << ", " << (int)frames[i].data[6] << ", " << (int)frames[i].data[7] << "]" << std::endl;

      uint16_t func_code = (frames[i].id & 0x780);
      uint8_t node_id = (frames[i].id & 0x7F);
      if (node_id >= NODE_ID::ID_MAX)
        continue;

      sensor = &sensors_[node_id];
      sensor->receive_point = ros::Time::now();
      switch (func_code)
      {
      case 0x700:
        LOG(WARNING) << "Node[" << node_id << "] login!";// 节点上线
        break;
      case 0x280:
      {
        if (frames[i].data[0] != 0)
        {
          // 传感器报错
          LOG(ERROR) << "Node[" << node_id << "] error!";
        }

        // 磁条感应状态
        if (high_frequency_log_)
        {
          std::stringstream ss("");
          ss << "Detection: [";
          if (frames[i].data[1] & 1)
            ss << " L";
          if (frames[i].data[1] & 2)
            ss << " M";
          if (frames[i].data[1] & 4)
            ss << " R";
          ss << " ]";
          LOG(INFO) << ss.str();
        }

        // 距离信息
        hinson_640n::Hinson640nData msg;
        msg.node_id = node_id;
        msg.distance_left = (frames[i].data[3] << 8) | frames[i].data[2];
        msg.distance_middle = (frames[i].data[5] << 8) | frames[i].data[4];
        msg.distance_right = (frames[i].data[7] << 8) | frames[i].data[6];
        sensor_data_pub_.publish(msg);
      }
      break;
      case 0x580: // 响应0x600
      {
        if (frames[i].data[0] == 0x60 && frames[i].data[1] == 0x01 && frames[i].data[2] == 0x18)
        {
          if (frames[i].data[3] == 0x02) // sync设置成功
          {
            sensor->synch_mode_set = true;
            LOG(WARNING) << "Node[" << node_id << "]: Mode[Sync & Async] ready!";
          }
          else if (frames[i].data[3] == 0x05) // timer 设置成功
          {
            sensor->timer_set = true;
            LOG(WARNING) << "Node[" << node_id << "]: Event-timer ready!";
          }
        }
      }
      break;
      default:
        break;
      }
    }
  }
  else
  {
    if (high_frequency_log_)
      LOG(ERROR) << "Receive data error!";
  }
}

void MagneticSensor::configSensors()
{
  for (int i = NODE_ID::ID_1; i < NODE_ID::ID_MAX; ++i)
  {
    if (!sensors_[i].send_set)
    {
      configTPDO2Sync(i);
      configTPDO2Timer(i);
      emitTPDO2(i);
    }
  }
}

void MagneticSensor::timeoutCheck()
{
  if (!high_frequency_log_)
    return;

  ros::Time now = ros::Time::now();
  for (int i = NODE_ID::ID_1; i < NODE_ID::ID_MAX; ++i)
  {
    if (sensors_[i].send_set && (now - sensors_[i].receive_point).toNSec() > 1e9) // 3 times
    {
      // 数据接收超时
      LOG(ERROR) << "Cann't receive sensor-data from CANBUS in 1s";
    }
  }
}

void MagneticSensor::logEnableCallback(const std_msgs::Bool::ConstPtr &input)
{
  high_frequency_log_ = input->data;
}

void MagneticSensor::eventLoop()
{
  configSensors();
  timeoutCheck();
  receiveData();
}